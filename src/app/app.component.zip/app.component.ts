import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs';
import { GRAPH1, GRAPH2 } from './data';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  private _alt?: boolean;
  public graph = GRAPH1;

  public update$: Subject<boolean> = new Subject();
  public center$: Subject<boolean> = new Subject();
  public zoomToFit$: Subject<boolean> = new Subject();

  ngOnInit(): void {
    this.update$.subscribe((_) => {
      this._alt = !this._alt;
      this.graph = this._alt ? GRAPH1 : GRAPH2;
    });
  }

  public onNodeSelect(event: any): void {
    console.log(event);
  }
}
